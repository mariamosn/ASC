Cum s-a implementat soluția ?
Output la performanțele obținute și discutie rezultate.
